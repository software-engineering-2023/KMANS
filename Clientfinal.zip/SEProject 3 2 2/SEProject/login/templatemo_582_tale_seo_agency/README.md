# Animated Notification Box

How To Create Notification Button UI/UX Design With Cool Animated Effects Using HTML, CSS, JS - Pure CSS/JS Tutorials   

► Subscribe Us: https://www.youtube.com/codingwithelias?sub_confirmation=1   

Notification Alert Menu 

How To make Animated Notification

![img](https://github.com/eliasFsDev/Animated-Notification-Box/blob/master/Notification.png)
